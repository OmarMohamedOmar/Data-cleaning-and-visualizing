# Load the dataset
library(readxl)
> project <- read_excel("C:/Users/SAIFUL/Desktop/Final Semester/Data Sceince/project.xlsx")
> View(project)    

# Check the dimensions of the dataset
dim(project)

# Get a summary of the dataset
summary(project)

# Check the structure of the dataset to understand data types and missing values
str(project)

# Identify the number of missing values in each column
missing_values <- sapply(project, function(x) sum(is.na(x)))
missing_values

# Remove rows with any missing values
project <- na.omit(project)

# Identify duplicate rows (excluding the first occurrence)
duplicates <- duplicated(project)
project[duplicates, ]
sum(duplicates)

# Using ggplot2 to create a box plot for Item_MRP (as an example)
library(ggplot2)
ggplot(project, aes(y = Item_MRP)) + geom_boxplot() + theme_minimal()


# Calculating Z-scores for Item_MRP (as an example)
z_scores <- scale(project$Item_MRP)
project_with_z <- data.frame(project, Z_Score = z_scores)

# Identifying outliers
outliers <- project_with_z[abs(project_with_z$Z_Score) > 3, ]

# Create a histogram for Item_MRP
ggplot(project, aes(x = Item_MRP)) +
  geom_histogram(binwidth = 10, fill = "blue", color = "black") +
  theme_minimal() +
  ggtitle("Distribution of Item Maximum Retail Price (MRP)") +
  xlab("Item MRP") +
  ylab("Frequency")

# creating a scatter plot to compare two numerical variables
ggplot(project, aes(x = Item_Visibility, y = Item_Weight)) +
  geom_point(alpha = 0.5) +
  theme_minimal() +
  ggtitle("Scatter Plot of Item MRP vs Outlet Sales") +
  xlab("Item Maximum Retail Price (MRP)") +
  ylab("Item Outlet Sales")

# Load the ggplot2 package
library(ggplot2)

# Create a bar chart for Item_Type
ggplot(project, aes(x = Item_Type)) +
  geom_bar(fill = "steelblue", color = "black") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) + # Rotate x labels for better readability
  labs(title = "Frequency of Each Item Type", x = "Item Type", y = "Frequency")

